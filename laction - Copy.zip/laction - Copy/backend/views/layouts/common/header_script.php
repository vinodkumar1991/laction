
<link rel="shortcut icon"
	href="<?php echo Yii::getAlias('@asset').'/img/favicon_1.ico'?>" />
<!-- Bootstrap core CSS -->
<link
	href="<?php echo Yii::getAlias('@asset').'/css/bootstrap.min.css'?>"
	rel="stylesheet" />
<link
	href="<?php echo Yii::getAlias('@asset').'/css/bootstrap-reset.css'?>"
	rel="stylesheet" />
<!--Animation css-->
<link href="<?php echo Yii::getAlias('@asset').'/css/animate.css'?>"
	rel="stylesheet" />

<!--Icon-fonts css-->
<link
	href="<?php echo Yii::getAlias('@asset').'/font-awesome/css/font-awesome.css'?>"
	rel="stylesheet" />
<link
	href="<?php echo Yii::getAlias('@asset').'/ionicon/css/ionicons.min.css'?>"
	rel="stylesheet" />
<link
	href="<?php echo Yii::getAlias('@asset').'/material-design-iconic-font/css/material-design-iconic-font.min.css'?>"
	rel="stylesheet" />
<link
	href="<?php echo Yii::getAlias('@asset').'/css/fileinput.min.css'?>"
	rel="stylesheet" type="text/css" />

<link
	href="<?php echo Yii::getAlias('@asset').'/datatables/jquery.dataTables.min.css'?>"
	rel="stylesheet" type="text/css" />
<link
	href="<?php echo Yii::getAlias('@asset').'/datatables/buttons.bootstrap.min.css'?>"
	rel="stylesheet" type="text/css" />
<link
	href="<?php echo Yii::getAlias('@asset').'/datatables/fixedHeader.bootstrap.min.css'?>"
	rel="stylesheet" type="text/css" />
<link
	href="<?php echo Yii::getAlias('@asset').'/datatables/responsive.bootstrap.min.css'?>"
	rel="stylesheet" type="text/css" />
<link
	href="<?php echo Yii::getAlias('@asset').'/datatables/scroller.bootstrap.min.css'?>"
	rel="stylesheet" type="text/css" />

<!-- Custom styles for this template -->
<link href="<?php echo Yii::getAlias('@asset').'/css/style.css'?>"
	rel="stylesheet" />
<link href="<?php echo Yii::getAlias('@asset').'/css/helper.css'?>"
	rel="stylesheet" />

<script src="<?php echo Yii::getAlias('@asset').'/js/jquery.js'?>"></script>
<script
	src="<?php echo Yii::getAlias('@asset').'/datatables/jquery.dataTables.min.js'?>"></script>
<script
	src="<?php echo Yii::getAlias('@asset').'/js/jquery.nicescroll.js'?>"></script>
<script
	src="<?php echo Yii::getAlias('@asset').'/jquery-datatables-editable/jquery.dataTables.js'?>"></script>
<script
	src="<?php echo Yii::getAlias('@asset').'/jquery-datatables-editable/datatables.editable.init.js'?>"></script>



