
<script src="<?php echo Yii::getAlias('@asset').'/js/jquery.app.js'?>"></script>

<script
	src="<?php echo Yii::getAlias('@asset').'/js/bootstrap.min.js'?>">
</script>
<script
	src="<?php echo Yii::getAlias('@asset').'/magnific-popup/magnific-popup.js'?>">
</script>
<script
	src="<?php echo Yii::getAlias('@asset').'/datatables/dataTables.bootstrap.js'?>">
</script>
