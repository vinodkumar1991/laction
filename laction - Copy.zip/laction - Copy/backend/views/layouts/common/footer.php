
<footer class="footer"> <?php echo date("Y").'&nbsp;&copy'.'&nbsp;'.Yii::$app->params['web_name'];?>  </footer>

