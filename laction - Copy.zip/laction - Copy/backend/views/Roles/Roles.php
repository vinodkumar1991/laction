<form method="post">
    Name : <input type="text" name="name" id="name"/>
    Code : <input type="text" name="code" id="code"/>
    Description : <input type="text" name="description" id="description"/>
    Status : <select name="status" id="status">
        <option value="">--Select Status--</option>
        <option value="1">Active</option>
        <option value="2">Inactive</option>
    </select>
    <input type="submit" name="common_create" id="common_create" value="Create"/>

</form>