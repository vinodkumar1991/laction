<?php
print_r($states);