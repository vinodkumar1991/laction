<?php
namespace app\modules\uploads;

use yii\base\Module;

class uploads_module extends Module
{

    public $controllerNamespace = 'app\modules\uploads\controllers';

    public function init()
    {
        parent::init();
    }
}
