<?php
namespace app\modules\notifications;

use yii\base\Module;

class notifications_module extends Module
{

    public $controllerNamespace = 'app\modules\notifications\controllers';

    public function init()
    {
        parent::init();
    }
}
