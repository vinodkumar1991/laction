<?php
namespace app\modules\slots;

use yii\base\Module;

class slots_module extends Module
{

    public $controllerNamespace = 'app\modules\slots\controllers';

    public function init()
    {
        parent::init();
    }
}
