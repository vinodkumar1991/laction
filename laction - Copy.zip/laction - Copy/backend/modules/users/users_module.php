<?php

namespace app\modules\users;

use yii\base\Module;

class users_module extends Module {

    
    public $controllerNamespace = 'app\modules\users\controllers';

    
    public function init() {
        parent::init();
    }

}
