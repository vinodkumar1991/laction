<?php
namespace app\modules\reports;

use yii\base\Module;

class reports_module extends Module
{

    public $controllerNamespace = 'app\modules\reports\controllers';

    public function init()
    {
        parent::init();
    }
}
