<?php
namespace backend\controllers;

use yii\web\Controller;

class GoController extends Controller
{
}
