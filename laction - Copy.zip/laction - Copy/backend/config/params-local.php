<?php
Yii::setAlias('web', 'http://localhost/laction/laction/admin/');
Yii::setAlias('asset', 'http://localhost/laction/laction/admin/assets/');

return [];
