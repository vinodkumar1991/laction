<?php
return [
    'adminEmail' => 'admin@example.com',
    'salt_key' => '$L^C&%T*O)N2018',
    'sms' => [
        'key' => '126609A0Wa1JMhGPn57eb2edf',
        'url' => 'https://control.msg91.com/api/sendhttp.php'
    ], // Need To Remove
    'web_name' => "L'Action Studios."
];
