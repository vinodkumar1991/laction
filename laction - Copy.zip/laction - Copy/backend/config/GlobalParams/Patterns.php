<?php
return [
    
    // Roles :: START
    'role.name' => '/^([A-Za-z ])+$/',
    // Roles :: END
    // Permissions :: START
    'permission.name' => '/^([A-Za-z ])+$/',
    // Permissions :: END
    // Categories :: START
    'category.name' => '/^([A-Za-z0-9 ])+$/',
    // Categories :: END
    // Sub Categories :: START
    'sub_category.name' => '/^([A-Za-z0-9 ])+$/'
    // Sub Categories :: END

];

