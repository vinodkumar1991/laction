<?php

return [
    'common.form.max_file_size' => 1000000, // 1 MB
];

