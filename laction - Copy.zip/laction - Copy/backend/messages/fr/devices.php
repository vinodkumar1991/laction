<?php

/**
 * @author Digital Today
 * @access public
 * @ignore The below messages used to give the lable name for textbox [ French ]
 */
return [
    //Devices :: START
    'devices.form.name' => 'prénom',
    'devices.form.code' => 'Code',
    'devices.form.description' => 'La description',
    'devices.form.status' => 'statut',
    'devices.form.image' => 'image',
    'devices.form.select_status' => '--Sélectionnez État--',
    'devices.form.active' => 'actif',
    'devices.form.inactive' => 'Inactif',
    'devices.form.submit_btn' => 'Créer',
    'devices.form.invalid_input' => 'Invalid Input est donné',
        //Devices :: END
];

