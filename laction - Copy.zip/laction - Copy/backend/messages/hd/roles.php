<?php

return [
    //Roles :: START
    'roles.form.name' => 'नाम',
    'roles.form.code' => 'कोड',
    'roles.form.description' => 'विवरण',
    'roles.form.status' => 'स्थिति',
    'roles.form.image' => 'की छवि',
    //Roles :: END
];

