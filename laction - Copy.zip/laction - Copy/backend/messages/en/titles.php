<?php
return [
    // Laction Admin
    'laction.admin' => 'Laction Admin | ',
    // Dashboard :: START
    'users.dashboard' => 'Superadmin',
    // Dashboard :: END
    
    // Slots :: START
    'slots.createslots' => 'Create Slots',
    'slots.slots' => 'Slots',
    // Slots :: END
    // Notifications :: START
    'notifications.templates' => 'Templates',
    'notifications.subjects' => 'Subjects',
    // Notifications :: END
    
    // Admin Users :: START
    'users.user' => 'Admin User',
    // Admin Users :: END
    
    // Settings :: START
    'settings.roles' => 'Roles',
    'settings.permissions' => 'Permissions',
    'settings.role_permissions' => 'Role Permissions',
    'settings.create_role_permissions' => 'Create Role Permissions',
    'settings.categories' => 'Categories',
    'settings.sub_categories' => 'Sub Categories'
    // Settings :: END

];

