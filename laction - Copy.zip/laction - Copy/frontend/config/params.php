<?php
return [
    'adminEmail' => 'admin@example.com',
    'google_api_key' => 'AIzaSyAmiJjq5DIg_K9fv6RE72OY__p9jz0YTMI',
];
