<?php
Yii::setAlias('fweb', 'http://localhost/laction/laction/');
Yii::setAlias('fasset', 'http://localhost/laction/laction/assets/');
Yii::setAlias('fimg', 'http://localhost/laction/laction/assets/img/');

return [];
