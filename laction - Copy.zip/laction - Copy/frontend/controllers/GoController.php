<?php
namespace frontend\controllers;

use yii\web\Controller;

class GoController extends Controller
{
}
