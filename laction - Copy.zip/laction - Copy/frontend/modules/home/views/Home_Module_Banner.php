<?php
echo 'Home Module Banner';