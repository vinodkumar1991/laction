<?php
echo $this->render('/Home_Module_Banner', []);
echo '<br/>';
echo $this->render('/Home_Module_Content', []);
