<?php
namespace app\modules\home;

use yii\base\Module;

class home_module extends Module
{

    public $controllerNamespace = 'app\modules\home\controllers';

    public function init()
    {
        parent::init();
    }
}
