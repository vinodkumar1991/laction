<?php
namespace app\modules\customers;

use yii\base\Module;

class customers_module extends Module
{

    public $controllerNamespace = 'app\modules\customers\controllers';

    public function init()
    {
        parent::init();
    }
}
