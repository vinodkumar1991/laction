<?php
echo 'Register A New Customer';