<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'sms' => [
        'key' => '126609A0Wa1JMhGPn57eb2edf',
        'url' => 'https://control.msg91.com/api/sendhttp.php'
    ]
];
